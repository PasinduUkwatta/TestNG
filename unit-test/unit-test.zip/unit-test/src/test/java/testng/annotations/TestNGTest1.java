package testng.annotations;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class TestNGTest1 {
    public static void main(String[] args){
        System.out.println("Hello TestNG !");
    }

    @AfterMethod
    private void afterMethod(){
        System.out.println("After");
    }

    @Test
    private void test1(){
        System.out.println("Test");
    }

    @Test
    private void test2(){
        System.out.println("Test2");
    }

    @BeforeMethod
    private void beforeMethod(){
        System.out.println("Before");
    }
    @BeforeClass
    private void beforeClass(){
        System.out.println("Before Class");
    }
}
